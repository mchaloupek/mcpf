{
	Creation: [
		{
			$published_on_type: 'date',
			published_on: 'Friday, 18 August, 2017',
			article: 'Asterias Biotheraputics Opens Additional Clinical Site for AST-OPC1 SCiStar Study',
			$text_type: 'textarea',
			text: 'Source: Asterias Biotherapeutics FREMONT, Calif., Aug. 23, 2017 (GLOBE NEWSWIRE) -- Asterias Biotherapeutics, Inc. (NYSE MKT:AST), a biotechnology company pioneering the field of regenerative medicine, today announced that Washington University School of Medicine in St. Louis, MO, has been added as a clinical site in the company’s ongoing SCiStar Phase 1/2a clinical trial of AST-OPC1...',
			$published_on_value: '2017-08-18'
		},
		{
			$published_on_type: 'date',
			published_on: 'Tuesday, 17 October, 2017',
			article: 'Bananas',
			$text_type: 'textarea',
			text: 'is bananas, b a n a n a s',
			$published_on_value: '2017-10-17'
		},
		{
			$published_on_type: 'date',
			published_on: 'Wednesday, 18 October, 2017',
			article: 'What is life?',
			$text_type: 'textarea',
			text: 'baby dont hurt me. dont hurt me, no more.',
			$published_on_value: '2017-10-18'
		},
		{
			$published_on_type: 'date',
			published_on: 'Thursday, 19 October, 2017',
			article: 'This is it',
			$text_type: 'textarea',
			text: 'Final Test',
			$published_on_value: '2017-10-19'
		}
	],
	meta: {
		last_edited: 1508778565
	}
}