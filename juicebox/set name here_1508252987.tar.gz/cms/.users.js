{
	users: [
		{
			username: 'demo',
			tags: [],
			salt: '6f988ae5124af047ab1181b443e7e7f4',
			hash: '3749861a270bfc2cf72e45e4472cc0c9cb21f8996b22171b0ddc8daa76e6ce4e',
			user_created_timestamp: 1508181972693
		}
	]
}